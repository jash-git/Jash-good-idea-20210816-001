# Real-Time_Background_remover
Using OpenCV and CVzone
