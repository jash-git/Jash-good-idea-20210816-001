# Watermark multiple images using OpenCV
